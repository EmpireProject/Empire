# coding: utf-8
"""
This is part of the MSS Python's module.
Source: https://github.com/BoboTiG/python-mss
"""


class ScreenShotError(Exception):
    """ Error handling class. """
